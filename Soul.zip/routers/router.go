package routers

import (
	"github.com/astaxie/beego"
	"Soul/controllers"
)

func init() {
	beego.Include(&controllers.Registercontrollers{})
	beego.Include(&controllers.Matchcontrollers{})
}
