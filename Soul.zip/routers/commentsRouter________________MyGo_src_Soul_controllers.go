package routers

import (
	"github.com/astaxie/beego"
	"github.com/astaxie/beego/context/param"
)

func init() {

	beego.GlobalControllerRouter["Soul/controllers:Matchcontrollers"] = append(beego.GlobalControllerRouter["Soul/controllers:Matchcontrollers"],
		beego.ControllerComments{
			Method: "Matched",
			Router: `/soul/matched`,
			AllowHTTPMethods: []string{"post"},
			MethodParams: param.Make(),
			Params: nil})

	beego.GlobalControllerRouter["Soul/controllers:Registercontrollers"] = append(beego.GlobalControllerRouter["Soul/controllers:Registercontrollers"],
		beego.ControllerComments{
			Method: "Test",
			Router: `/soul`,
			AllowHTTPMethods: []string{"get"},
			MethodParams: param.Make(),
			Params: nil})

	beego.GlobalControllerRouter["Soul/controllers:Registercontrollers"] = append(beego.GlobalControllerRouter["Soul/controllers:Registercontrollers"],
		beego.ControllerComments{
			Method: "Get_info",
			Router: `/soul/get_info`,
			AllowHTTPMethods: []string{"post"},
			MethodParams: param.Make(),
			Params: nil})

	beego.GlobalControllerRouter["Soul/controllers:Registercontrollers"] = append(beego.GlobalControllerRouter["Soul/controllers:Registercontrollers"],
		beego.ControllerComments{
			Method: "Match_id",
			Router: `/soul/match_id`,
			AllowHTTPMethods: []string{"post"},
			MethodParams: param.Make(),
			Params: nil})

}
