package controllers

import (
	"github.com/astaxie/beego"
	"fmt"
	"Soul/models"
)

type Registercontrollers struct {
	beego.Controller
}

//@router /soul [get]
func (this *Registercontrollers)Test(){
	this.TplName="check.html"
}

//@router /soul/get_info [post]
func (this *Registercontrollers)Get_info(){

	class,err:=this.GetInt("class")
	if err!=nil {
		beego.Debug(err)
	}

	var student models.Student
	student.Stu_id=this.GetString("stu_id")
	student.Stu_class=class
	student.Sex,_=this.GetInt("sex")
	student.Aim,_=this.GetInt("aim")
	student.Wechat=this.GetString("wechat")
	student.QQ=this.GetString("qq")
	student.Tag_main,_=this.GetInt("tag_main")
	student.Tag1,_=this.GetInt("tag1")
	student.Tag2,_=this.GetInt("tag2")
	student.Tag3,_=this.GetInt("tag3")
	student.Tag4,_=this.GetInt("tag4")
	student.Tag5,_=this.GetInt("tag5")
	student.Tag6,_=this.GetInt("tag6")
	student.Tag7,_=this.GetInt("tag7")
	student.Tag8,_=this.GetInt("tag8")
	student.Tag9,_=this.GetInt("tag9")
	student.Tag10,_=this.GetInt("tag10")
	student.Tag11,_=this.GetInt("tag11")
	student.Tag12,_=this.GetInt("tag12")

 	fmt.Println(student)

	_,flag:=models.Student_find(student.Stu_id,student.Stu_class,student.Sex)

	if !flag {
		models.Student_input(student)
		result:= struct {
			Flag bool
			Err int
			Msg string
		}{
			Flag:true,
			Err:0,
			Msg:"Succeed!",
		}
		this.Data["json"]=result
		this.ServeJSON()
	}else{
		models.Student_update(student)
		result:= struct {
			Flag bool
			Err int
			Msg string
		}{
			Flag:true,
			Err:0,
			Msg:"Update succeed!",
		}
		this.Data["json"]=result
		this.ServeJSON()
	}
}

//@router /soul/match_id [post]
func (this *Registercontrollers)Match_id(){
	var stu_info models.Stu_info
	stu_info.Stu_id=this.GetString("stu_id")
	stu_info.Stu_name=this.GetString("stu_name")
	class,_:=this.GetInt("stu_class")
	fmt.Println(stu_info)
	flag,err,_:=models.Stu_info_find(stu_info.Stu_id,stu_info.Stu_name,class)

	result:=struct {
		Flag bool
		Err int
		Msg string
	}{
		Flag:false,
		Err:0,
		Msg:"",
	}

	if flag {
		result.Flag=true
		result.Msg="Success!"
	}else if err==1 {
		result.Err=1
		result.Msg="姓名不匹配！"
	}else if err==2{
		result.Err=2
		result.Msg="学号未找到！"
	}else {
		result.Err=3
		result.Msg="非参与活动对象"
	}

	this.Data["json"]=result
	this.ServeJSON()
}
