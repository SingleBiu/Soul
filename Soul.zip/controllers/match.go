package controllers

import (
	"github.com/astaxie/beego"
	"Soul/models"
	"fmt"
	"github.com/astaxie/beego/orm"
)

type Matchcontrollers struct {
	beego.Controller
}

type Info struct {
	M_flage     bool
	Main_tag    int
	Tags        [12]int
	QQ          string
	Wechat      string
}

//@router /soul/matched [post]
func (this *Matchcontrollers) Matched(){

	var stu_info models.Stu_info
	stu_info.Stu_id=this.GetString("stu_id")
	stu_info.Stu_name=this.GetString("stu_name")
	class,_:=this.GetInt("stu_class")
	fmt.Println(stu_info)
	flag,err,class:=models.Stu_info_find(stu_info.Stu_id,stu_info.Stu_name,class)

	aim_id,flag:=models.Result_find(stu_info.Stu_id,class)

	var info Info

	if flag {
		if class==1 {
			o:=orm.NewOrm()
			stu_g:=models.Stu_jg_girl{}
			_,err:=o.QueryTable("Stu_jg_girl").Filter("Stu_id",aim_id).All(&stu_g)
			if err!=nil{
				beego.Debug(err)
			}
			if stu_g.Id==0{
				stu_b:=models.Stu_jg_boy{}
				_,err:=o.QueryTable("Stu_jg_boy").Filter("Stu_id",aim_id).All(&stu_b)
				if err!=nil{
					beego.Debug(err)
				}
				if stu_b.Id==0{
					info.M_flage=false
				}else{
					info.M_flage=true
				}
				info.Main_tag=stu_b.Tag_main
				info.QQ=stu_b.QQ
				info.Wechat=stu_b.Wechat
				info.Tags=[12]int{
					stu_b.Tag1,
					stu_b.Tag2,
					stu_b.Tag3,
					stu_b.Tag4,
					stu_b.Tag5,
					stu_b.Tag6,
					stu_b.Tag7,
					stu_b.Tag8,
					stu_b.Tag9,
					stu_b.Tag10,
					stu_b.Tag11,
					stu_b.Tag12}

			}else{
				info.Main_tag=stu_g.Tag_main
				info.QQ=stu_g.QQ
				info.Wechat=stu_g.Wechat
				info.Tags=[12]int{
					stu_g.Tag1,
					stu_g.Tag2,
					stu_g.Tag3,
					stu_g.Tag4,
					stu_g.Tag5,
					stu_g.Tag6,
					stu_g.Tag7,
					stu_g.Tag8,
					stu_g.Tag9,
					stu_g.Tag10,
					stu_g.Tag11,
					stu_g.Tag12}
			}
		}else{
			o:=orm.NewOrm()
			stu_g:=models.Stu_js_girl{}
			_,err:=o.QueryTable("Stu_js_girl").Filter("Stu_id",aim_id).All(&stu_g)
			if err!=nil{
				beego.Debug(err)
			}
			if stu_g.Id==0{
				stu_b:=models.Stu_js_boy{}
				_,err:=o.QueryTable("Stu_js_boy").Filter("Stu_id",aim_id).All(&stu_b)
				if err!=nil{
					beego.Debug(err)
				}
				if stu_b.Id==0{
					info.M_flage=false
				}else{
					info.M_flage=true
				}
				info.Main_tag=stu_b.Tag_main
				info.QQ=stu_b.QQ
				info.Wechat=stu_b.Wechat
				info.Tags=[12]int{
					stu_b.Tag1,
					stu_b.Tag2,
					stu_b.Tag3,
					stu_b.Tag4,
					stu_b.Tag5,
					stu_b.Tag6,
					stu_b.Tag7,
					stu_b.Tag8,
					stu_b.Tag9,
					stu_b.Tag10,
					stu_b.Tag11,
					stu_b.Tag12}
			}else{
				info.Main_tag=stu_g.Tag_main
				info.QQ=stu_g.QQ
				info.Wechat=stu_g.Wechat
				info.Tags=[12]int{
					stu_g.Tag1,
					stu_g.Tag2,
					stu_g.Tag3,
					stu_g.Tag4,
					stu_g.Tag5,
					stu_g.Tag6,
					stu_g.Tag7,
					stu_g.Tag8,
					stu_g.Tag9,
					stu_g.Tag10,
					stu_g.Tag11,
					stu_g.Tag12}
			}
		}
	}

	result:=struct {
		Flag bool
		Err int
		Msg string
		Info Info
	}{
		Flag:false,
		Err:0,
		Msg:"",
		Info:info,
	}

	if flag {
		result.Flag=true
		result.Msg="Success!"
	}else if err==1 {
		result.Err=1
		result.Msg="姓名不匹配！"
	}else if err==2{
		result.Err=2
		result.Msg="学号未找到！"
	}else{
		result.Err=3
		result.Msg="非参与活动对象"
	}

	this.Data["json"]=result
	this.ServeJSON()
}
