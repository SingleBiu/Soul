package main

import (
	_ "Soul/routers"
	"github.com/astaxie/beego"
	"Soul/models"
)

func init(){
	models.RegisterDB()
}

func main() {
	//models.TableCreater()
	models.Match()
	//models.Studemt_update()
	//models.Test_inputer()
	//models.Stu_info_find("B20170304332","颜骕沣")
	beego.Run()
}

