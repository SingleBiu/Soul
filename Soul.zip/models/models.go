package models

import (
	"github.com/astaxie/beego/orm"
	_ "github.com/go-sql-driver/mysql"
	"github.com/astaxie/beego"
	"fmt"
)

type Student struct {
	Id        int `orm:"auto"`
	Stu_id    string
	Stu_class int
	Sex       int
	Aim       int
	Wechat    string
	QQ        string
	Tag_main  int
	Tag1      int
	Tag2      int
	Tag3      int
	Tag4      int
	Tag5      int
	Tag6      int
	Tag7      int
	Tag8      int
	Tag9      int
	Tag10     int
	Tag11     int
	Tag12     int
	Matched   int `orm:"default(1)"`
}

type Stu_jg_boy Student

type Stu_jg_girl Student

type Stu_js_boy Student

type Stu_js_girl Student

type Result struct {
	Id    int `orm:"auto"`
	Js_id string
	Jg_id string
	Percent int
}

type Stu_info struct{
	Stu_id  	string `orm:"pk"`
	Stu_name 	string
}

type Stu_js_15 struct {
	Stu_info
}

type Stu_js_16 struct {
	Stu_info
}

type Stu_js_17 struct {
	Stu_info
}

type Stu_js_18 struct {
	Stu_info
}

type Stu_jg_15 struct {
	Stu_info
}

type Stu_jg_16 struct {
	Stu_info
}

type Stu_jg_17 struct {
	Stu_info
}

type Stu_jg_18 struct {
	Stu_info
}

//数据库注册
func RegisterDB(){
	orm.Debug = true

	orm.RegisterModel(
		new(Result),
		new(Stu_js_boy),
		new(Stu_js_girl),
		new(Stu_jg_boy),
		new(Stu_jg_girl),
		new(Stu_jg_15),
		new(Stu_jg_16),
		new(Stu_jg_17),
		new(Stu_jg_18),
		new(Stu_js_15),
		new(Stu_js_16),
		new(Stu_js_17),
		new(Stu_js_18),)
	//注册驱动
	orm.RegisterDriver("mysql", orm.DRMySQL)
	//注册默认数据库
	orm.RegisterDataBase("default", "mysql", "root"+":"+"123456"+"@/soul?charset=utf8")
}

//自动建表
func TableCreater(){
	orm.RunSyncdb("default",false,true)
}



//根据学号查找
func Student_find(stu_id string,stu_class int,sex int) (interface{},bool){
	o:=orm.NewOrm()
	switch {
		case stu_class==1&&sex==1:
			student:=Stu_js_boy{}
			_,err:=o.QueryTable("Stu_js_boy").Filter("Stu_id",stu_id).All(&student)
			if err!=nil{
				beego.Debug(err)
			}
			if student.Id==0{
				return 0,false
			}
			return student,true
		case stu_class==1&&sex==2:
			student:=Stu_js_girl{}
			_,err:=o.QueryTable("Stu_js_girl").Filter("Stu_id",stu_id).All(&student)
			if err!=nil{
				beego.Debug(err)
			}
			if student.Id==0{
				return 0,false
			}
			return student,true
		case stu_class==2&&sex==1:
			student:=Stu_jg_boy{}
			_,err:=o.QueryTable("Stu_jg_boy").Filter("Stu_id",stu_id).All(&student)
			if err!=nil{
				beego.Debug(err)
			}
			if student.Id==0{
				return 0,false
			}
			return student,true
		case stu_class==2&&sex==2:
			student:=Stu_jg_girl{}
			_,err:=o.QueryTable("Stu_jg_girl").Filter("Stu_id",stu_id).All(&student)
			if err!=nil{
				beego.Debug(err)
			}
			if student.Id==0{
				return 0,false
			}
			return student,true
		case stu_class==3:
			var result Result
			_,err:=o.QueryTable("Result").Filter("Stu_id",stu_id).All(&result)
			if err!=nil{
				beego.Debug(err)
			}
			if result.Id==0{
				return 0,false
			}
			return result,true
		default:
			return 0,false
	}
}

//表单写入
func Student_input(student Student){
	o:=orm.NewOrm()
	var table string

	student.Stu_class=stu_info_byid(student.Stu_id)

	switch {
	case student.Stu_class==1&&student.Sex==1:
		table="soul.stu_js_boy"
	case student.Stu_class==1&&student.Sex==2:
		table="soul.stu_js_girl"
	case student.Stu_class==2&&student.Sex==1:
		table="soul.stu_jg_boy"
	case student.Stu_class==2&&student.Sex==2:
		table="soul.stu_jg_girl"
	}

	sql:="INSERT INTO "+table+" (stu_id,stu_class,sex,aim,wechat,q_q,tag_main,tag1,tag2,tag3,tag4,tag5,tag6,tag7,tag8,tag9,tag10,tag11,tag12) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
	o.Raw(sql,student.Stu_id,
		      student.Stu_class,
		      student.Sex,
		      student.Aim,
		      student.Wechat,
		      student.QQ,
		      student.Tag_main,
		      student.Tag1,
		      student.Tag2,
		      student.Tag3,
		      student.Tag4,
		      student.Tag5,
		      student.Tag6,
		      student.Tag7,
		      student.Tag8,
		      student.Tag9,
		      student.Tag10,
		      student.Tag11,
		      student.Tag12).Exec()
}

//标签更新
func Student_update(student Student){
	o:=orm.NewOrm()
	var table string

	switch {
		case student.Stu_class==1&&student.Sex==1:
			table="soul.stu_js_boy"
		case student.Stu_class==1&&student.Sex==2:
			table="soul.stu_js_girl"
		case student.Stu_class==2&&student.Sex==1:
			table="soul.stu_jg_boy"
		case student.Stu_class==2&&student.Sex==2:
			table="soul.stu_jg_girl"
	}

	sql:="UPDATE "+table+" SET stu_id=? , stu_class=? , sex=? , aim=? , wechat=? , q_q=? , tag_main=? , tag1=? , tag2=? , tag3=? , tag4=? , tag5=? , tag6=? , tag7=? , tag8=? , tag9=? , tag10=? , tag11=? , tag12=? WHERE stu_id='"+student.Stu_id+"'"
	o.Raw(sql,student.Stu_id,
		student.Stu_class,
		student.Sex,
		student.Aim,
		student.Wechat,
		student.QQ,
		student.Tag_main,
		student.Tag1,
		student.Tag2,
		student.Tag3,
		student.Tag4,
		student.Tag5,
		student.Tag6,
		student.Tag7,
		student.Tag8,
		student.Tag9,
		student.Tag10,
		student.Tag11,
		student.Tag12).Exec()
}

//学号姓名表单查找
func Stu_info_find(id string,name string,class int)(bool,int,int){
	switch class {
		case 1:
			if flag,msg:=stu_info_js(id,name);flag {
				return flag,msg,1
			}else if msg==1 {
				return flag,msg,1
			}

			if flag,msg:=stu_info_jg(id,name);flag {
				return flag,msg,2
			}else if msg==1 {
				return flag,msg,2
			}

			return false,3,0
		case 2:
			if flag,msg:=stu_info_jg(id,name);flag {
				return flag,msg,2
			}else if msg==1 {
				return flag,msg,2
			}

			if flag,msg:=stu_info_js(id,name);flag {
				return flag,msg,1
			}else if msg==1 {
				return flag,msg,1
			}

			return false,3,0
		case 3:
			if flag,msg:=stu_info_jg(id,name);flag {
				return flag,msg,2
			}else if msg==1 {
				return flag,msg,2
			}

			if flag,msg:=stu_info_js(id,name);flag {
				return flag,msg,1
			}else if msg==1 {
				return flag,msg,1
			}

			return false,3,0
		default:
			return false,3,0
	}
}

//计数院优先的学号姓名表单查找实现
func stu_info_js(id string,name string)(bool,int){
	o:=orm.NewOrm()
	for count:=15;count<19;count++ {
		switch {
		case count==15:
			var stu_info Stu_js_15
			_,err:=o.QueryTable("Stu_js_15").Filter("Stu_id",id).All(&stu_info)
			if err!=nil{
				beego.Debug(err)
			}
			if stu_info.Stu_name==""{
				continue
			}else if stu_info.Stu_name==name{
				return true,0
			}else{
				return false,1
			}
		case count==16:
			var stu_info Stu_js_16
			_,err:=o.QueryTable("Stu_js_16").Filter("Stu_id",id).All(&stu_info)
			if err!=nil{
				beego.Debug(err)
			}
			if stu_info.Stu_name==""{
				continue
			}else if stu_info.Stu_name==name{
				return true,0
			}else{
				return false,1
			}
		case count==17:
			var stu_info Stu_js_17
			_,err:=o.QueryTable("Stu_js_17").Filter("Stu_id",id).All(&stu_info)
			if err!=nil{
				beego.Debug(err)
			}
			if stu_info.Stu_name==""{
				continue
			}else if stu_info.Stu_name==name{
				return true,0
			}else{
				return false,1
			}
		case count==18:
			var stu_info Stu_js_18
			_,err:=o.QueryTable("Stu_js_18").Filter("Stu_id",id).All(&stu_info)
			if err!=nil{
				beego.Debug(err)
			}
			if stu_info.Stu_name==""{
				continue
			}else if stu_info.Stu_name==name{
				return true,0
			}else{
				return false,1
			}
		}
	}
	return false,2
}

//经管院优先的学号姓名表单查找实现
func stu_info_jg(id string,name string)(bool,int){
	o:=orm.NewOrm()
	for count:=15;count<19;count++ {
		switch {
		case count==15:
			var stu_info Stu_jg_15
			_,err:=o.QueryTable("Stu_jg_15").Filter("Stu_id",id).All(&stu_info)
			if err!=nil{
				beego.Debug(err)
			}
			if stu_info.Stu_name==""{
				continue
			}else if stu_info.Stu_name==name{
				return true,0
			}else{
				return false,1
			}
		case count==16:
			var stu_info Stu_jg_16
			_,err:=o.QueryTable("Stu_jg_16").Filter("Stu_id",id).All(&stu_info)
			if err!=nil{
				beego.Debug(err)
			}
			if stu_info.Stu_name==""{
				continue
			}else if stu_info.Stu_name==name{
				return true,0
			}else{
				return false,1
			}
		case count==17:
			var stu_info Stu_jg_17
			_,err:=o.QueryTable("Stu_jg_17").Filter("Stu_id",id).All(&stu_info)
			if err!=nil{
				beego.Debug(err)
			}
			if stu_info.Stu_name==""{
				continue
			}else if stu_info.Stu_name==name{
				return true,0
			}else{
				return false,1
			}
		case count==18:
			var stu_info Stu_jg_18
			_,err:=o.QueryTable("Stu_jg_18").Filter("Stu_id",id).All(&stu_info)
			if err!=nil{
				beego.Debug(err)
			}
			if stu_info.Stu_name==""{
				continue
			}else if stu_info.Stu_name==name{
				return true,0
			}else{
				return false,1
			}
		}
	}
	return false,2
}

//外院转入寻找班级
func stu_info_byid(id string)int{
	o:=orm.NewOrm()
	for count:=15;count<19;count++ {
		switch {
		case count==15:
			var stu_info Stu_js_15
			_,err:=o.QueryTable("Stu_js_15").Filter("Stu_id",id).All(&stu_info)
			if err!=nil{
				beego.Debug(err)
			}
			if stu_info.Stu_name==""{
				continue
			}else{
				return 1
			}
		case count==16:
			var stu_info Stu_js_16
			_,err:=o.QueryTable("Stu_js_16").Filter("Stu_id",id).All(&stu_info)
			if err!=nil{
				beego.Debug(err)
			}
			if stu_info.Stu_name==""{
				continue
			}else{
				return 1
			}
		case count==17:
			var stu_info Stu_js_17
			_,err:=o.QueryTable("Stu_js_17").Filter("Stu_id",id).All(&stu_info)
			if err!=nil{
				beego.Debug(err)
			}
			if stu_info.Stu_name==""{
				continue
			}else{
				return 1
			}
		case count==18:
			var stu_info Stu_js_18
			_,err:=o.QueryTable("Stu_js_18").Filter("Stu_id",id).All(&stu_info)
			if err!=nil{
				beego.Debug(err)
			}
			if stu_info.Stu_name==""{
				continue
			}else{
				return 1
			}
		}
	}

	for count:=15;count<19;count++ {
		switch {
		case count==15:
			var stu_info Stu_jg_15
			_,err:=o.QueryTable("Stu_jg_15").Filter("Stu_id",id).All(&stu_info)
			if err!=nil{
				beego.Debug(err)
			}
			if stu_info.Stu_name==""{
				continue
			}else{
				return 2
			}
		case count==16:
			var stu_info Stu_jg_16
			_,err:=o.QueryTable("Stu_jg_16").Filter("Stu_id",id).All(&stu_info)
			if err!=nil{
				beego.Debug(err)
			}
			if stu_info.Stu_name==""{
				continue
			}else{
				return 2
			}
		case count==17:
			var stu_info Stu_jg_17
			_,err:=o.QueryTable("Stu_jg_17").Filter("Stu_id",id).All(&stu_info)
			if err!=nil{
				beego.Debug(err)
			}
			if stu_info.Stu_name==""{
				continue
			}else{
				return 2
			}
		case count==18:
			var stu_info Stu_jg_18
			_,err:=o.QueryTable("Stu_jg_18").Filter("Stu_id",id).All(&stu_info)
			if err!=nil{
				beego.Debug(err)
			}
			if stu_info.Stu_name==""{
				continue
			}else{
				return 2
			}
		}
	}

	return 2
}


func Match(){

	o:=orm.NewOrm()
	sql:="SELECT * FROM soul.stu_js_boy WHERE stu_id!=''"
	stu_js_boy:=[]Stu_js_boy{}
	_,err:=o.Raw(sql).QueryRows(&stu_js_boy)
	if err!=nil{
		beego.Debug(err)
	}

	sql="SELECT * FROM soul.stu_js_girl WHERE stu_id!=''"
	stu_js_girl:=[]Stu_js_girl{}
	_,err=o.Raw(sql).QueryRows(&stu_js_girl)
	if err!=nil{
		beego.Debug(err)
	}

	sql="SELECT * FROM soul.stu_jg_boy WHERE stu_id!=''"
	stu_jg_boy:=[]Stu_jg_boy{}
	_,err=o.Raw(sql).QueryRows(&stu_jg_boy)
	if err!=nil{
		beego.Debug(err)
	}

	sql="SELECT * FROM soul.stu_jg_girl WHERE stu_id!=''"
	stu_jg_girl:=[]Stu_jg_girl{}
	_,err=o.Raw(sql).QueryRows(&stu_jg_girl)
	if err!=nil{
		beego.Debug(err)
	}

	//遍历计数男生
	for _,stu_js:=range stu_js_boy{
		if stu_js.Matched==1{
			result_new:=Result{Js_id:stu_js.Stu_id,Percent:0}
			js_tag:=[12]int{
				stu_js.Tag1,
				stu_js.Tag2,
				stu_js.Tag3,
				stu_js.Tag4,
				stu_js.Tag5,
				stu_js.Tag6,
				stu_js.Tag7,
				stu_js.Tag8,
				stu_js.Tag9,
				stu_js.Tag10,
				stu_js.Tag11,
				stu_js.Tag12}

			switch stu_js.Aim {
			case 1:
				result_new=js_bTojg_b(stu_js,js_tag,stu_jg_boy,result_new)
				if result_new.Jg_id!="" {
					for key,stu:=range stu_jg_boy{
						if stu.Stu_id==result_new.Jg_id{
							stu_jg_boy[key].Matched=0
							break
						}
					}
				}
			case 2:
				result_new=js_bTojg_g(stu_js,js_tag,stu_jg_girl,result_new)
				fmt.Println(12)
				if result_new.Jg_id!="" {
					for key,stu:=range stu_jg_girl{
						if stu.Stu_id==result_new.Jg_id{
							stu_jg_girl[key].Matched=0
							fmt.Println(stu.Stu_id)
							break
						}
					}
				}
			case 3:
				result_new=js_bTojg_g(stu_js,js_tag,stu_jg_girl,result_new)
				fmt.Println(13)
				if result_new.Jg_id!="" {
					for key,stu:=range stu_jg_girl{
						if stu.Stu_id==result_new.Jg_id{
							stu_jg_girl[key].Matched=0
							fmt.Println(stu.Stu_id)
							break
						}
					}
				}
/*				if result_new.Percent!=12{
					result_new=js_bTojg_b(stu_js,js_tag,stu_jg_boy,result_new)
				}*/
			}

			if result_new.Jg_id!=""{
				matched_update(result_new)
				Resule_input(result_new)
			}
		}
	}

	//遍历计数女生
	for _,stu_js:=range stu_js_girl{
		if stu_js.Matched==1{
			result_new:=Result{Js_id:stu_js.Stu_id,Percent:0}
			js_tag:=[12]int{
				stu_js.Tag1,
				stu_js.Tag2,
				stu_js.Tag3,
				stu_js.Tag4,
				stu_js.Tag5,
				stu_js.Tag6,
				stu_js.Tag7,
				stu_js.Tag8,
				stu_js.Tag9,
				stu_js.Tag10,
				stu_js.Tag11,
				stu_js.Tag12}

			switch stu_js.Aim {
			case 1:
				result_new=js_gTojg_b(stu_js,js_tag,stu_jg_boy,result_new)
				fmt.Println(21)
				if result_new.Jg_id!="" {
					for key,stu:=range stu_jg_boy{
						if stu.Stu_id==result_new.Jg_id{
							stu_jg_boy[key].Matched=0
							fmt.Println(stu.Stu_id)
							break
						}
					}
				}
			case 2:
				result_new=js_gTojg_g(stu_js,js_tag,stu_jg_girl,result_new)
				fmt.Println(22)
				if result_new.Jg_id!="" {
					for key,stu:=range stu_jg_girl{
						if stu.Stu_id==result_new.Jg_id{
							stu_jg_girl[key].Matched=0
							fmt.Println(stu.Stu_id)
							break
						}
					}
				}
			case 3:
				result_new=js_gTojg_g(stu_js,js_tag,stu_jg_girl,result_new)
				if result_new.Percent!=12{
					result_new=js_gTojg_b(stu_js,js_tag,stu_jg_boy,result_new)
					fmt.Println(23)
					if result_new.Jg_id!="" {
						for key,stu:=range stu_jg_boy{
							if stu.Stu_id==result_new.Jg_id{
								stu_jg_boy[key].Matched=0
								fmt.Println(stu.Stu_id)
								break
							}
						}
					}
				}else{
					fmt.Println(24)
					if result_new.Jg_id!="" {
						for key,stu:=range stu_jg_girl{
							if stu.Stu_id==result_new.Jg_id{
								stu_jg_girl[key].Matched=0
								fmt.Println(stu.Stu_id)
								break
							}
						}
					}
				}
			}

			if result_new.Jg_id!=""{
				matched_update(result_new)
				Resule_input(result_new)
			}
		}
	}

}

func Resule_input(result Result){
	o:=orm.NewOrm()
	o.Insert(&result)
}

func js_bTojg_g(stu_js Stu_js_boy,js_tag [12]int,stu_jg_girl []Stu_jg_girl,result_new Result) Result{
	for _,stu_jg:=range stu_jg_girl{
		if stu_jg.Tag_main==0{
			stu_jg.Tag_main=5
		}
		if stu_jg.Matched==1&&(stu_jg.Aim==1||stu_jg.Aim==3){
			this_percent:=0
/*			jg_tag:=[12]int{
				stu_jg.Tag1,
				stu_jg.Tag2,
				stu_jg.Tag3,
				stu_jg.Tag4,
				stu_jg.Tag5,
				stu_jg.Tag6,
				stu_jg.Tag7,
				stu_jg.Tag8,
				stu_jg.Tag9,
				stu_jg.Tag10,
				stu_jg.Tag11,
				stu_jg.Tag12}

			for _,js_tag_v:=range js_tag{
				if js_tag_v!=0{

					for _,jg_tag_v:=range jg_tag {
						if js_tag_v==jg_tag_v&&jg_tag_v!=0{
							this_percent++
							break
						}
					}
				}
			}*/

			//if this_percent>result_new.Percent{
				result_new.Jg_id=stu_jg.Stu_id
				result_new.Percent=this_percent
			//}

			//if this_percent==12{
				return result_new
			//}
		}
	}
	return result_new
}

func js_bTojg_b(stu_js Stu_js_boy,js_tag [12]int,stu_jg_boy []Stu_jg_boy,result_new Result) Result{
	for _,stu_jg:=range stu_jg_boy{
		if stu_jg.Tag_main==0{
			stu_jg.Tag_main=5
		}
		if stu_jg.Matched==1&&stu_js.Tag_main==stu_jg.Tag_main&&(stu_jg.Aim==1||stu_jg.Aim==3){
			this_percent:=0
/*			jg_tag:=[12]int{
				stu_jg.Tag1,
				stu_jg.Tag2,
				stu_jg.Tag3,
				stu_jg.Tag4,
				stu_jg.Tag5,
				stu_jg.Tag6,
				stu_jg.Tag7,
				stu_jg.Tag8,
				stu_jg.Tag9,
				stu_jg.Tag10,
				stu_jg.Tag11,
				stu_jg.Tag12}

			for _,js_tag_v:=range js_tag{
				if js_tag_v!=0{
					for _,jg_tag_v:=range jg_tag {
						if js_tag_v==jg_tag_v&&jg_tag_v!=0{
							this_percent++
							break
						}
					}
				}
			}*/

			//if this_percent>result_new.Percent{
				result_new.Jg_id=stu_jg.Stu_id
				result_new.Percent=this_percent
			//}

			//if this_percent==12{
				return result_new
			//}
		}
	}
	return result_new
}

func js_gTojg_b(stu_js Stu_js_girl,js_tag [12]int,stu_jg_boy []Stu_jg_boy,result_new Result) Result{
	for _,stu_jg:=range stu_jg_boy{
		if stu_jg.Tag_main==0{
			stu_jg.Tag_main=5
		}
		if stu_jg.Matched==1&&stu_jg.Aim>1{
			this_percent:=0
/*			jg_tag:=[12]int{
				stu_jg.Tag1,
				stu_jg.Tag2,
				stu_jg.Tag3,
				stu_jg.Tag4,
				stu_jg.Tag5,
				stu_jg.Tag6,
				stu_jg.Tag7,
				stu_jg.Tag8,
				stu_jg.Tag9,
				stu_jg.Tag10,
				stu_jg.Tag11,
				stu_jg.Tag12}

			for _,js_tag_v:=range js_tag{
				if js_tag_v!=0{
					for _,jg_tag_v:=range jg_tag {
						if js_tag_v==jg_tag_v&&jg_tag_v!=0{
							this_percent++
							break
						}
					}
				}
			}
*/
			//if this_percent>result_new.Percent{
				result_new.Jg_id=stu_jg.Stu_id
				result_new.Percent=this_percent
			//}

			//if this_percent==12{
				return result_new
			//}
		}
	}
	return result_new
}

func js_gTojg_g(stu_js Stu_js_girl,js_tag [12]int,stu_jg_girl []Stu_jg_girl,result_new Result) Result{
	for _,stu_jg:=range stu_jg_girl{
		if stu_jg.Tag_main==0{
			stu_jg.Tag_main=5
		}
		if stu_jg.Matched==1&&stu_jg.Aim>1{
			this_percent:=0
/*			jg_tag:=[12]int{
				stu_jg.Tag1,
				stu_jg.Tag2,
				stu_jg.Tag3,
				stu_jg.Tag4,
				stu_jg.Tag5,
				stu_jg.Tag6,
				stu_jg.Tag7,
				stu_jg.Tag8,
				stu_jg.Tag9,
				stu_jg.Tag10,
				stu_jg.Tag11,
				stu_jg.Tag12}

			for _,js_tag_v:=range js_tag{
				if js_tag_v!=0{
					for _,jg_tag_v:=range jg_tag {
						if js_tag_v==jg_tag_v&&jg_tag_v!=0{
							this_percent++
							break
						}
					}
				}
			}*/

			//if this_percent>result_new.Percent{
				result_new.Jg_id=stu_jg.Stu_id
				result_new.Percent=this_percent
			//}

			//if this_percent==12{
				return result_new
			//}
		}
	}
	return result_new
}

func matched_update(result Result){
	if _,flag:=Student_find(result.Js_id,1,1);flag{
		o:=orm.NewOrm()
		sql:="UPDATE soul.stu_js_boy SET matched=? WHERE stu_id=? "
		o.Raw(sql,0,result.Js_id).Exec()
	}else{
		o:=orm.NewOrm()
		sql:="UPDATE soul.stu_js_girl SET matched=? WHERE stu_id=? "
		o.Raw(sql,0,result.Js_id).Exec()
	}

	if _,flag:=Student_find(result.Jg_id,2,1);flag{
		o:=orm.NewOrm()
		sql:="UPDATE soul.stu_jg_boy SET matched=? WHERE stu_id=? "
		o.Raw(sql,0,result.Jg_id).Exec()
	}else{
		o:=orm.NewOrm()
		sql:="UPDATE soul.stu_jg_girl SET matched=? WHERE stu_id=? "
		o.Raw(sql,0,result.Jg_id).Exec()
	}
}


func Result_find(id string,class int)(string,bool){
	o:=orm.NewOrm()
	result:=Result{}
	if class==1{
		result.Js_id=id
		_,err:=o.QueryTable("Result").Filter("Js_id",id).All(&result)
		if err!=nil{
			beego.Debug(err)
		}
		if result.Percent!=0{
			return result.Jg_id,true
		}
	}else{
		result.Jg_id=id
		_,err:=o.QueryTable("Result").Filter("Jg_id",id).All(&result)
		if err!=nil {
			beego.Debug(err)
		}
		if result.Percent!=0{
			return result.Js_id,true
		}
	}
	return "",false
}
/*
//存储到数组内
func Get_out_test(id int)interface{}{
	o:=orm.NewOrm()
	switch id {
	case 1:
		sql:="SELECT * FROM soul.stu_js_boy WHERE stu_id!=''"
		result:=[]Stu_js_boy{}
		num,err:=o.Raw(sql).QueryRows(&result)
		if err==nil{
			fmt.Println(num)
		}
		fmt.Println(result)
		return result
	case 2:
		sql:="SELECT * FROM soul.stu_js_girl WHERE stu_id!=''"
		result:=[]Stu_js_girl{}
		num,err:=o.Raw(sql).QueryRows(&result)
		if err==nil{
			fmt.Println(num)
		}
		fmt.Println(result)
		return result
	case 3:
		sql:="SELECT * FROM soul.stu_jg_boy WHERE stu_id!=''"
		result:=[]Stu_jg_boy{}
		num,err:=o.Raw(sql).QueryRows(&result)
		if err==nil{
			fmt.Println(num)
		}
		fmt.Println(result)
		return result
	case 4:
		sql:="SELECT * FROM soul.stu_jg_girl WHERE stu_id!=''"
		result:=[]Stu_jg_girl{}
		num,err:=o.Raw(sql).QueryRows(&result)
		if err==nil{
			fmt.Println(num)
		}
		fmt.Println(result)
		return result
	}
	return nil
}
*/