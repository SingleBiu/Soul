
'use strict';

var pages=[$('.list1'),$('.list2'),$('.list3'),$('.list4')];

function Nextpage(i){
	// var minwith=pages[i].width()*0.9+"px";
	// var minheight=pages[i].height()*0.9+"px";
	// pages[i].find("*").css("display","none");
	pages[i].animate({opacity:0},500,function(){
		pages[i].removeClass("list_active");
		pages[i+1].addClass("list_active");	
		pages[i+1].animate({opacity:1},500);	
	});
}

function CheckID(id){
	var stu_id=/^[Bb]\d{4}(03|09)\d{5}$/;

	if(stu_id.test(id)){
		return true;
	}else{
		return false;
	}
}

function PlanetMove(){
	var planet1=$('#planet1');
	var planet2=$('#planet2');
	var p1_top=planet1.position().top+20;
	var p1_left=planet1.position().left+Number(planet1.css("margin-left").replace('px',''))+180;
	var p2_top=p1_top+planet1.height()*0.5;
	var p2_left=p1_left-100;
	var p3_top=p2_top+planet1.height()*0.5;
	var p3_left=p2_left-100;
	var p0_top=p1_top+30;
	var p0_left=p1_left-50;
	var p4_top=p3_top-10;
	var p4_left=p3_left+50;
	planet2.css({"position":"absolute","top":p0_top,"left":p0_left,"width":0});
	
	planet2.animate({
		"width":30,
		"top":p1_top,
		"left":p1_left
	},500,function(){
		planet2.animate({
			"width":50,
			"top":p2_top,
			"left":p2_left			
		},1000,function(){
			planet2.animate({
				"width":30,
				"top":p3_top,
				"left":p3_left	
			},1000,function(){
				planet2.animate({
					"width":0,
					"top":p4_top,
					"left":p4_left						
				},500);
			});
		});
	});	
}

function Show_notic(){
	$('#myModal').on('shown.bs.modal', function () {
	  	$('#myInput').focus()
	})	
}

var id_have=0;
var name_have=0;
var list1_checked=0

function Show_btn1(){
	if(id_have==1&&name_have==1){		
    	$('.list1_btn').removeAttr("disabled");
 		list1_checked=1;
	}else{
		if($('.list1_btn').attr("disabled")==undefined){
    		$('.list1_btn').attr("disabled",true);
    	} 
    	list1_checked=0; 	
	}
}

$('input[name="inputid"]').bind('input',function(event){     
    var stu_id=/^[Bb]\d{11}$/;
    var line_height=$('#l1_input_div').height()+'px';

    $('.fa-check').css("lineHeight",line_height);

    if(stu_id.test($(this).val())){ 	
    	id_have=1;
    	$('#id_icon').stop().animate({opacity:1},200);
/*	    	$(this).bind('keypress',function(event){
     	if(event.keyCode==13&&id_have==1&&name_have==1){ 
	     		if(CheckID($(this).val())){
	     			$('#myModal').modal('show');
	     			Show_notic();
	     		}else{
	     			alert("本次活动暂时只对在读的经管以及计数院学生开放");
	     			window.location.reload();
	     		}	   		  
	   		}   		
    	})   */	
    }else{
    	id_have=0;
    	$('#id_icon').animate({opacity:0},500);   	
    }
    Show_btn1();
});

$('input[name="inputname"]').bind('input',function(){
	var value=$(this).val();
	if(value.length>0){
		name_have=1;
		$('#name_icon').stop().animate({opacity:1},200);		
/*		$(this).bind('keypress',function(event){
	     	if(event.keyCode==13&&id_have==1&&name_have==1){ 
//	     		if(CheckID($('input[name="inputid"]').val())){
	     			$('#myModal').modal('show');
	     			Show_notic();
	     		}else{
	     			alert("本次活动暂时只对在读的经管以及计数院学生开放");
	     			window.location.reload();
	     		}	  		  
	   		}   		
    	})*/
	}else{
		$('#name_icon').animate({opacity:0},500);
		name_have=0;
	}
	Show_btn1();
});
/*
$('.list1_btn').click(function(){ 
//	if(CheckID($('input[name="inputid"]').val())){
		// $('#myModal').on('shown.bs.modal', function () {
		//   $('#myInput').focus()
		// })
		Show_notic();
		if($('input[name="inputid"]').val()="B20170303124"){
			alert("主任你怎么来了 hhhhhh");
			window.location.reload();
		}		
		//Nextpage(0);
	}else{
		alert("本次活动暂时只对经管以及计数院学生开放");
	    window.location.reload();
	}  
});
*/
$('#next_btn').click(function(){
	var id=$("input[name='inputid']").val();
	var js_test=/^[Bb]\d{4}03\d{5}$/;
	var jg_test=/^[Bb]\d{4}09\d{5}$/;

	if(js_test.test(id)){
		var this_class=1;
	}else if(jg_test.test(id)){
		var this_class=2;
	}else{
		var this_class=3;
	}

	console.log(this_class);

	$.ajax({
		type: 'POST',
		url: '/soul/match_id',
		dataType: 'json',
		data: {
			"stu_name":$('input[name="inputname"]').val(),
			"stu_class":this_class
		},
		success: function(res){
			if(res.Flag){
				Nextpage(0);
			}else if(res.Err==1){
				alert("学号姓名不匹配\n如果有疑问请联系官微或官Q");
				window.location.reload();
			}else if(res.Err==2){
				alert("未找到该学号\n如果有疑问请联系官微或官Q");
				window.location.reload();
			}else if(res.Err==2){
				alert("本次活动暂时只对经管以及计数院学生开放");
				window.location.reload();
			}		
		},
		error: function(res){
			alert("服务器繁忙，请稍后再试！");
			window.location.reload();
		}	
	});	
});

$('.list2_btn').click(function(){   
    Nextpage(1);
});


$('.list3_btn').click(function(){ 
	var tags=new Array(12);
	var tag_main=0;
	var now=0;
	var id=$("input[name='inputid']").val();
	var id_test=/^[Bb]\d{4}03\d{5}$/;
	var this_class=0;

	if(id_test.test(id)){
		this_class=1;
	}else{
		this_class=2;
	}

	$('.tag').each(function(){
		if(!$(this).hasClass('main_tag')){
			$(this).find('li').each(function(){
				if($(this).hasClass('pointed')){
					tags[now]=$(this).val();
					now++;
				}
			});			
		}else{
			$(this).find('li').each(function(){
				if($(this).hasClass('pointed')){
					tag_main=$(this).val();
				}
			});	
		}
	})
    console.log(tag_main);
	$.ajax({
		type: 'POST',
		url: '/soul/get_info',
		dataType: 'json',
		data: {
			"stu_id":id,
			"class":this_class,
			"sex":$("input[type='radio']:checked").val(),
			"wechat":$("input[name='inputwechat']").val(),
			"qq":$("input[name='inputqq']").val(),
			"aim":$('.selectpicker').val(),
			"tag_main":tag_main,
			"tag1":tags[0],
			"tag2":tags[1],
			"tag3":tags[2],
			"tag4":tags[3],
			"tag5":tags[4],
			"tag6":tags[5],
			"tag7":tags[6],
			"tag8":tags[7],
			"tag9":tags[8],
			"tag10":tags[9],
			"tag11":tags[10],
			"tag12":tags[11]
		},
		success: function(res){
			console.log(res);
			if(res.Err==0){
				Nextpage(2);
			}else{
				alert("该账号已参加本次活动");
				window.location.reload();
			}
			
		},	
		error: function(res){
			console.log(res);
			alert("提交失败！");
			window.location.reload();
		}
	});   
});


var pointed=0;
var main_pointed=0;
$('.tag').find('li').click(function(){
	var idnow=$(this).parent().attr('id');
	if($(this).hasClass('pointed')){
		$(this).animate({backgroundColor:'#ccc'},200);
		$(this).removeClass('pointed');
		if(idnow==0){
		}else{
			pointed--;
		}		
	}else if(idnow==0){
		var classname='.main_tag_title';
		var color=$(classname).css('background');
		$('.main_tag').find('.pointed').animate({backgroundColor:'#ccc'},200);
		$('.main_tag').find('.pointed').removeClass('pointed');
		$(this).animate({backgroundColor:color},200);
		$(this).addClass("pointed");
	}else if(pointed<12){
		var classname='.title'+idnow;
		var color=$(classname).css('background');
		$(this).animate({backgroundColor:color},200);
		$(this).addClass("pointed");
		pointed++;		
	}else{
		alert("最多选择12个标签！");
	}
});

$(window).on('load',function(){
	PlanetMove();
	var timer=setInterval(PlanetMove, 3500);
});