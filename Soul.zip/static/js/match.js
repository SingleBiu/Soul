'use strict';

var pages=[$('.list1'),$('.list2'),$('.list3')];

function Nextpage(i){
	pages[i].animate({opacity:0},500,function(){
		pages[i].removeClass("list_active");
		pages[i+1].addClass("list_active");	
		pages[i+1].animate({opacity:1},500);	
	});
}


$(".list1_btn").click(function(){
	var id=$("input[name='inputid']").val();
	var js_test=/^[Bb]\d{4}03\d{5}$/;
	var jg_test=/^[Bb]\d{4}09\d{5}$/;

	if(js_test.test(id)){
		var this_class=1;
	}else if(jg_test.test(id)){
		var this_class=2;
	}else{
		var this_class=3;
	}

	$.ajax({
		type: 'POST',
		url: 'soul/matched',
		dataType: 'json',
		data: {
			"stu_id":$('input[name="inputid"]').val(),
			"stu_name":$('input[name="inputname"]').val(),
			"stu_class":this_class
		},
		success: function(res){
			if(res.Flag){
				Creater(res);
				Nextpage(0);
			}else if(res.Err==1){
				alert("学号姓名不匹配\n如果有疑问请联系官微或官Q");
				window.location.reload();
			}else if(res.Err==2){
				alert("未找到该学号\n如果有疑问请联系官微或官Q");
				window.location.reload();
			}else if(!res.Info.M_flage){
				alert("你的星球可能遗落在了其他地方，等待你在其他地方和它相遇");
				window.location.reload();
			}
		}
	});
});

$(".list22_btn").click(function(){
	Nextpage(1);
});

function Creater(res){
	var main_tag="";
	switch (res.Info.Main_tag){
		case 1:
			main_tag="学习";
			break;
		case 2:
			main_tag="出游";
			break;
		case 3:
			main_tag="游戏";
			break;
		case 4:
			main_tag="聊天";
			break;
		case 5:
			main_tag="其他";
			break;
	}

	$(".part1").append("<div class='tag_main center-block'>"+main_tag+"</div>");

	if(res.Info.QQ!=""){
		$(".part3").append("<h4>QQ:"+res.Info.QQ+"</h4>");
	}

	if(res.Info.Wechat!=""){
		$(".part3").append("<h4>微信:"+res.Info.Wechat+"</h4>");
	}
}